from django.urls import path, re_path
from .views import post_model_list_view, post_model_detail_view, \
    post_model_create_view, post_model_update_view,\
    post_model_delete_view

app_name = 'blog'

urlpatterns = [

    re_path('(?P<id>\d+)/update/', post_model_update_view , name = "update"),
    re_path('(?P<id>\d+)/delete/', post_model_delete_view , name = "delete"),
    re_path('(?P<id>\d+)/', post_model_detail_view , name = "detail"),
    re_path('create/', post_model_create_view , name = "create"),
    re_path('list/', post_model_list_view , name = "list"),
]

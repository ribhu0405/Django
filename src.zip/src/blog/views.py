from django.shortcuts import render, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, Http404, HttpResponseRedirect
from .models import PostModel
from .forms import PostModelForm


def post_model_detail_view(request, id = None ):

    obj = get_object_or_404(PostModel, id = id)
    template = "blog/detail-view.html"
    context = {
        "object": obj
    }
    return render(request, template, context)


def post_model_create_view(request):

    form = PostModelForm(request.POST or None)
    context = {
        "form": form
    }

    if form.is_valid() :
        obj = form.save(commit=False)
        obj.save()
        messages.success(request, "Yet Another Blog Post Created")

        context = {
            "form" : PostModelForm()
        }
        # return HttpResponseRedirect("/blog/{id}/".format(id = obj.id))

    template = "blog/create-view.html"

    return render(request, template, context)


def post_model_delete_view(request, id = None):

    obj = get_object_or_404(PostModel, id=id)

    print(request.method)

    if request.method == "POST":

        obj.delete()

        messages.success(request, str(obj.title) + " Post Deleted")

        return HttpResponseRedirect("/blog/list/")

    context = {
        "object": obj
    }
    template = "blog/delete-view.html"

    return render(request, template, context)


def post_model_update_view(request, id = None):

    obj = get_object_or_404(PostModel, id=id)

    form = PostModelForm(request.POST or None, instance=obj)
    context = {
        "object" : obj,
        "form": form
    }

    if form.is_valid() :
        obj = form.save(commit=False)
        obj.save()
        messages.success(request, "Blog Updated")

        context = {
            "form" : PostModelForm()
        }
        return HttpResponseRedirect("/blog/{id}/".format(id = obj.id))

    template = "blog/update-view.html"

    return render(request, template, context)


def post_model_list_view(request):

    qs = PostModel.objects.all()
    print(request.user)

    context = {

        "object_list" : qs

    }
    if request.user.is_authenticated :
        template = "blog/list-view.html"
    else :
        template = "blog/list-view-public.html"
        return HttpResponseRedirect("/login/")

    return render(request, template, context)
